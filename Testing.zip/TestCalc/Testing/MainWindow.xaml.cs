﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;    

namespace Testing
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, RoutedEventArgs e)
        {
            int A = Convert.ToInt32(FirstBox.Text);
            int B = Convert.ToInt32(SecondBox.Text);
            int C = A + B; 
            Sum.Text = C.ToString();
            int D = A - B;
            Dif.Text = D.ToString();
            int E = A * B;
            Mult.Text = E.ToString();
            int F = A / B;
            Div.Text = F.ToString();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            //int first = Convert.ToInt32(FirstBox.Text);
            //int second = Convert.ToInt32(SecondBox.Text);   


            ////string message = Console.ReadLine();
            ////string new_message = "";

            //string path = @"Input.txt";
            //StreamWriter sw = new StreamWriter(path, false);
            //sw.WriteLine(first, second);
            //sw.Close();

            //string path1 = @"Result.txt";

            //StreamWriter sw1 = new StreamWriter(path1, false);

            //sw1.WriteLine(new_message);

            //sw1.Close();

            //Console.WriteLine("Подсчет и запись выполнены и занесены в файл Result.txt!");
            //Console.WriteLine(new_message);

        }
    }
}
